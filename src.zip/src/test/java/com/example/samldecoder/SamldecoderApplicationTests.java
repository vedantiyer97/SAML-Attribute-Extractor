package com.example.samldecoder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamldecoderApplicationTests {

	@Test
	void contextLoads() {
	}

}
